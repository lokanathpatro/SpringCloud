package com.cts.ecom.sales.model;

import java.util.List;

public class ItemList {

	private List<Item> items;

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public ItemList() {
	}
}


