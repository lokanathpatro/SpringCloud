package com.javainuse.controllers;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.javainuse.model.Employee;
@Controller
public class ConsumerControllerClient {


	@Autowired
	private LoadBalancerClient loadBalancer;

	public void getEmployee() throws RestClientException, IOException {

		ServiceInstance serviceInstance=loadBalancer.choose("EMPLOYEE-ZUUL-SERVICE");

		System.out.println(serviceInstance.getUri());

		String baseUrl=serviceInstance.getUri().toString();

		baseUrl=baseUrl+"/producer/employee";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
			response=restTemplate.exchange(baseUrl,
					HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody());
	}


	@GetMapping(path = "/Employee", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> getEmp() throws RestClientException, IOException {

		ServiceInstance serviceInstance=loadBalancer.choose("EMPLOYEE-ZUUL-SERVICE");

		System.out.println(serviceInstance.getUri());

		String baseUrl=serviceInstance.getUri().toString();

		baseUrl=baseUrl+"/producer/employee";

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Employee> response=null;
		try{
			response=restTemplate.exchange(baseUrl,
					HttpMethod.GET, getHeaders(),Employee.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(baseUrl);
		System.out.println(response.getBody().getName());
		return new ResponseEntity<Employee>(response.getBody()	, HttpStatus.OK);
	}
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}