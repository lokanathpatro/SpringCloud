package com.cts.ecom.item.resource;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cts.ecom.item.model.Item;
import com.cts.ecom.item.service.ItemService;

@RestController
public class ItemResource {
	
	@Autowired
	private ItemService ItemService;
	
	//private ItemRepository ItemRepository;
	
	@GetMapping("/Items")
	public List<Item> getAllItems() {
		return ItemService.getAllItems();
	}
	
	@GetMapping("/Items/{id}")
	public Item retrieveStudent(@PathVariable long id) {
		return ItemService.getItem(id);
	}
	
	@PostMapping("/Items")
	public ResponseEntity<Object> createItem(@RequestBody Item Item) {
		Item savedItem = ItemService.createItem(Item);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedItem.getId()).toUri();

		return ResponseEntity.created(location).build();

	}

}
