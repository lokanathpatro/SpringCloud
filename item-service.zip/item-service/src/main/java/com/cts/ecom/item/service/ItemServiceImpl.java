package com.cts.ecom.item.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.cts.ecom.item.model.Item;
import com.cts.ecom.item.repo.ItemRepository;


@Service
public class ItemServiceImpl implements ItemService {

    @Autowired
    private ItemRepository ItemRepository;

    @Override
    public Item createItem(Item Item) {
        return ItemRepository.save(Item);
    }

    @Override
    public Item getItem(Long id) {
        return ItemRepository.findOne(id);
    }
    

    @Override
    public Item editItem(Item Item) {
        return ItemRepository.save(Item);
    }

    @Override
    public void deleteItem(Item Item) {
        ItemRepository.delete(Item);
    }

    @Override
    public void deleteItem(Long id) {
        ItemRepository.delete(id);
    }

    @Override
    public List<Item> getAllItems(int pageNumber, int pageSize) {
        return ItemRepository.findAll(new PageRequest(pageNumber, pageSize)).getContent();
    }

    @Override
    public List<Item> getAllItems() {
        return ItemRepository.findAll();
    }

    @Override
    public long countItems() {
        return ItemRepository.count();
    }
}
