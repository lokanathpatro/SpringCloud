package com.cts.ecom.sales.resource;

import java.io.IOException;
import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cts.ecom.sales.model.Customer_SOS;
import com.cts.ecom.sales.model.Item;
import com.cts.ecom.sales.model.ItemList;
import com.cts.ecom.sales.model.SalesRequest;
import com.cts.ecom.sales.model.Sales_order;
import com.cts.ecom.sales.repo.CustomerSosRepository;

import jnr.ffi.types.size_t;

public class SalesResource {

	@Autowired
	CustomerSosRepository customerSosRepository;
	@PostMapping("/sales")
	public ResponseEntity<Sales_order> createItem(@RequestBody SalesRequest req) {

		Customer_SOS customer = customerSosRepository.findOne(req.getCustomer_id());
		if(customer!=null) {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<Sales_order> response=null;
			//ResponseEntity<ItemList> res=null;

			List<String> itemNames=req.getItemNames();
			//res=restTemplate.exchange("http://localhost:8083/items",
			//		HttpMethod.GET, getHeaders(),ItemList.class);
			
			ItemList itemList =restTemplate.getForObject( "http://localhost:8083/items", ItemList.class);
			Long totalprice=0l;
			int itemQuantity=0;
			String itemsDesc;
			
			for (String itemName : itemNames) {
				
				for (Item item : itemList.getItems()) {
					if(item.getName().equals(itemName)) {
						totalprice=totalprice+item.getPrice();
						++itemQuantity;
						itemsDesc.concat(itemQuantity+" Item "+item.getDescription()+" ");
					}
				}
				
			}
			
			Sales_order sales_order = new Sales_order();
			sales_order.setCust_id(req.getCustomer_id());
			sales_order.setOrder_date(getCurrentTimeUsingDate());
			sales_order.setOrder_desc(itemsDesc);
			System.out.println(response.getBody());
		}
		
		
		String Order_Id;
		return new ResponseEntity<Sales_order>(response.getBody()	, HttpStatus.OK);

	}
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	public static String getCurrentTimeUsingDate() {
	    Date date = new Date();
	    String strDateFormat = "hh:mm:ss a";
	    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
	    String formattedDate= dateFormat.format(date);
	    return formattedDate;
	}
	
}
